<footer class="container">
    <p>&copy; 2025 My E-commerce Site</p>
</footer>