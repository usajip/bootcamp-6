<h1 class="font-bold text-[30px]">My Store</h1>
