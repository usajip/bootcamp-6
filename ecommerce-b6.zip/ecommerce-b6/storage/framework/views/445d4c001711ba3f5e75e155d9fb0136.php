<h1 class="font-bold text-[30px]">My Store</h1>
<?php /**PATH /Users/aji/Documents/eduwork-bootcamp/bootcamp-6/ecommerce-b6/resources/views/components/application-logo.blade.php ENDPATH**/ ?>