<div class="card">
  <img src="<?php echo e(asset('assets/' . $image)); ?>" class="card-img-top img-fluid" alt="...">
  <div class="card-body">
    <span class="badge rounded-pill text-bg-primary mb-1"><?php echo e($category); ?></span>
    <h5 class="card-title"><?php echo e($title); ?></h5>
    <p class="card-text"><?php echo e($description); ?></p>
    <p class="card-text fw-bold">Rp<?php echo e(number_format($price, 0, ',', '.')); ?></p>
    <a href="<?php echo e($link); ?>" class="btn btn-primary">Lihat Detail</a>
  </div>
</div><?php /**PATH /Users/aji/Documents/eduwork-bootcamp/bootcamp-6/ecommerce-b6/resources/views/components/product-card.blade.php ENDPATH**/ ?>