<?php if (isset($component)) { $__componentOriginal49c970d3d2c20c30f4b317d550dfbdd2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal49c970d3d2c20c30f4b317d550dfbdd2 = $attributes; } ?>
<?php $component = App\View\Components\TemplateBootstrap::resolve(['title' => 'Transaction Status Page with Component'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('template-bootstrap'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\TemplateBootstrap::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="col-12 mb-4">
        <?php if(session('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo e(session('error')); ?>

        </div>
        <?php endif; ?>
    </div>
    <h2>Welcome to the Transaction Status Page</h2>
    <p>This is the content of the transaction status page.</p>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Transaction Details</h5>
            <?php if(isset($transaction)): ?>
                <p><strong>Transaction ID:</strong> <?php echo e($transaction->id); ?></p>
                <p><strong>Name</strong> <?php echo e($transaction->name); ?></p>
                <p><strong>Address:</strong> <?php echo e($transaction->address); ?></p>
                <p><strong>Phone:</strong> <?php echo e($transaction->phone); ?></p>
                <p><strong>Total Amount:</strong> Rp<?php echo e(number_format($transaction->total_amount, 0, ',', '.')); ?></p>
                <?php if(auth()->check() && auth()->user()->role === 'admin'): ?>
                    <form action="<?php echo e(route('transaction.update-status', $transaction->id)); ?>" method="POST" class="mb-3 d-flex align-items-center" style="gap: 0.5rem;">
                        <?php echo csrf_field(); ?>
                        <label for="status" class="mb-0"><strong>Status:</strong></label>
                        <select name="status" id="status" class="form-select form-select-sm w-auto mx-2">
                            <option value="pending" <?php echo e($transaction->status == 'pending' ? 'selected' : ''); ?>>Pending</option>
                            <option value="paid" <?php echo e($transaction->status == 'paid' ? 'selected' : ''); ?>>Paid</option>
                            <option value="shipped" <?php echo e($transaction->status == 'shipped' ? 'selected' : ''); ?>>Shipped</option>
                            <option value="completed" <?php echo e($transaction->status == 'completed' ? 'selected' : ''); ?>>Completed</option>
                            <option value="cancelled" <?php echo e($transaction->status == 'cancelled' ? 'selected' : ''); ?>>Cancelled</option>
                        </select>
                        <button type="submit" class="btn btn-sm btn-success">Update</button>
                    </form>
                <?php else: ?>
                    <p><strong>Status:</strong> <?php echo e($transaction->status); ?></p>
                <?php endif; ?>
                <div class="card p-4">
                    <?php $__currentLoopData = $transaction->transaction_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex align-items-start <?php echo e($loop->last ? '' : 'border-bottom mb-4 pb-4'); ?>" style="gap: 1.5rem;">
                            <img src="<?php echo e(asset('assets/'.$item->product->image_url)); ?>" alt="<?php echo e($item->product->name); ?>" class="rounded" style="width:100px; height:100px; object-fit:cover;">
                            <div class="flex-grow-1">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <h5 class="mb-1"><?php echo e($item->product->name); ?></h5>
                                        <div class="text-muted small mb-1"><?php echo e($item->product->description); ?></div>
                                        <div class="text-muted small">Quantity: <?php echo e($item->quantity); ?></div>
                                    </div>
                                    <div class="text-end ms-3">
                                        <div class="fw-bold fs-5">Rp<?php echo e(number_format($item->price, 0, ',', '.')); ?></div>
                                        <?php if($item->quantity > 1): ?>
                                            <div class="text-muted small">Rp<?php echo e(number_format($item->price * $item->quantity, 0, ',', '.')); ?> total</div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                
                <?php
                    // url confirmation order to whatsapp api
                    $whatsapp_number = '6281234567890'; // replace with your WhatsApp number
                    $message = "Hello, I would like to confirm my order for Transaction ID: " . $transaction->id . ".";
                    $whatsapp_url = "https://wa.me/{$whatsapp_number}?text=" . urlencode($message);
                ?>
                <a href="<?php echo e($whatsapp_url); ?>" target="_blank" class="btn btn-primary mt-3">Konfirmasi Pembayaran</a>
            <?php else: ?>
                <p>No transaction details available.</p>
            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal49c970d3d2c20c30f4b317d550dfbdd2)): ?>
<?php $attributes = $__attributesOriginal49c970d3d2c20c30f4b317d550dfbdd2; ?>
<?php unset($__attributesOriginal49c970d3d2c20c30f4b317d550dfbdd2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal49c970d3d2c20c30f4b317d550dfbdd2)): ?>
<?php $component = $__componentOriginal49c970d3d2c20c30f4b317d550dfbdd2; ?>
<?php unset($__componentOriginal49c970d3d2c20c30f4b317d550dfbdd2); ?>
<?php endif; ?><?php /**PATH /Users/aji/Documents/eduwork-bootcamp/bootcamp-6/ecommerce-b6/resources/views/transaction-status.blade.php ENDPATH**/ ?>