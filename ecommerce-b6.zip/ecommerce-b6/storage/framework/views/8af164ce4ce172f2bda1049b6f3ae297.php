<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Product')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6">
                    <?php if (isset($component)) { $__componentOriginaladf429c5a9f071fe4f090bb1f187d2bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaladf429c5a9f071fe4f090bb1f187d2bc = $attributes; } ?>
<?php $component = App\View\Components\SuccessErrorInfo::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('success-error-info'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SuccessErrorInfo::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaladf429c5a9f071fe4f090bb1f187d2bc)): ?>
<?php $attributes = $__attributesOriginaladf429c5a9f071fe4f090bb1f187d2bc; ?>
<?php unset($__attributesOriginaladf429c5a9f071fe4f090bb1f187d2bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaladf429c5a9f071fe4f090bb1f187d2bc)): ?>
<?php $component = $__componentOriginaladf429c5a9f071fe4f090bb1f187d2bc; ?>
<?php unset($__componentOriginaladf429c5a9f071fe4f090bb1f187d2bc); ?>
<?php endif; ?>
                    <div class="flex justify-between mb-4">
                        <h3 class="text-lg font-bold">Daftar Produk</h3>
                        <a href="<?php echo e(route('products.create')); ?>" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                            + Tambah Produk
                        </a>
                    </div>
                    <table class="w-full bg-white border">
                        <thead>
                            <tr>
                                <th class="py-2 px-4 border-b">ID</th>
                                <th class="py-2 px-4 border-b">Nama</th>
                                <th class="py-2 px-4 border-b">Deskripsi</th>
                                <th class="py-2 px-4 border-b">Harga</th>
                                <th class="py-2 px-4 border-b">Stok</th>
                                <th class="py-2 px-4 border-b">Gambar</th>
                                <th class="py-2 px-4 border-b">Kategori</th>
                                <th class="py-2 px-4 border-b">Total trx</th>
                                <th class="py-2 px-4 border-b">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="py-2 px-4 border-b"><?php echo e($product->id); ?></td>
                                    <td class="py-2 px-4 border-b"><?php echo e($product->name); ?></td>
                                    <td class="py-2 px-4 border-b"><?php echo e($product->description); ?></td>
                                    <td class="py-2 px-4 border-b">Rp <?php echo e(number_format($product->price, 0, ',', '.')); ?></td>
                                    <td class="py-2 px-4 border-b"><?php echo e($product->stock); ?></td>
                                    <td class="py-2 px-4 border-b">
                                        <?php if($product->image_url): ?>
                                            <img src="<?php echo e(asset('assets/' . $product->image_url)); ?>" alt="<?php echo e($product->name); ?>" class="w-16 h-16 object-cover">
                                        <?php else: ?>
                                            N/A
                                        <?php endif; ?>
                                    </td>
                                    <td class="py-2 px-4 border-b"><?php echo e($product->product_category->name ?? 'Uncategorized'); ?></td>
                                    <td class="py-2 px-4 border-b"><?php echo e($product->transaction_items_count); ?></td>
                                    <td class="py-2 px-4 border-b">
                                        <a href="<?php echo e(route('products.edit', $product->id)); ?>" class="bg-blue-500 hover:bg-blue-700 text-white py-1 px-3 rounded mr-2">Edit</a>
                                        <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="POST" class="inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" onclick="return confirm('Yakin ingin menghapus produk: <?php echo e($product->name); ?> ini?')" class="bg-red-500 hover:bg-red-700 text-white py-1 px-3 rounded">Hapus</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="py-2 px-4 text-center">Tidak ada produk ditemukan.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>

                    <?php echo e($products->links()); ?>

                </div>
            </div>
        </div>
    </div>
    <?php $__env->startPush('styles'); ?>
        <link rel="stylesheet" href="https://cdn.datatables.net/2.3.6/css/dataTables.dataTables.min.css">
    <?php $__env->stopPush(); ?>
    <?php $__env->startPush('scripts'); ?>
        
        <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
        <script src="//cdn.datatables.net/2.3.6/js/dataTables.min.js"></script>
        <script>
            let table = new DataTable('#myTable');
        </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/aji/Documents/eduwork-bootcamp/bootcamp-6/ecommerce-b6/resources/views/admin/product/index.blade.php ENDPATH**/ ?>