<?php if (isset($component)) { $__componentOriginal49c970d3d2c20c30f4b317d550dfbdd2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal49c970d3d2c20c30f4b317d550dfbdd2 = $attributes; } ?>
<?php $component = App\View\Components\TemplateBootstrap::resolve(['title' => 'Product Detail Page with Component'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('template-bootstrap'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\TemplateBootstrap::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container my-5">
        <div class="row">
            <div class="col-12 mb-4">
                <?php if(session('success')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('success')); ?>

                </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(session('error')); ?>

                </div>
                <?php endif; ?>
            </div>
            <div class="col-md-6">
                <img src="<?php echo e(asset('assets/'.$product->image_url)); ?>" class="img-fluid rounded" alt="Product Image">
            </div>
            <div class="col-md-6">
                <h2 class="mb-3"><?php echo e($product->name); ?></h2>
                <p class="text-muted mb-2">Category: <span class="fw-bold"><?php echo e($product->product_category->name); ?></span></p>
                <h4 class="text-primary mb-3">Rp<?php echo e(number_format($product->price, 0, ',', '.')); ?></h4>
                <p><?php echo e($product->description); ?></p>
                <form action="<?php echo e(route('cart.add', ['productId' => $product->id])); ?>" method="POST" class="mt-4">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="quantity" class="form-label">Quantity</label>
                        <input type="number" class="form-control w-25" id="quantity" name="quantity" value="1" min="1">
                    </div>
                    <button type="submit" class="btn btn-success">
                        <i class="bi bi-cart-plus"></i> Add to Cart
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <div class="container my-5">
        <h3 class="mb-4">Recommended Products</h3>
        <div class="row">
            <?php $__currentLoopData = $recommendedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 mb-4">
                <?php if (isset($component)) { $__componentOriginalecfc721726b8b5798826c96d529d8b59 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalecfc721726b8b5798826c96d529d8b59 = $attributes; } ?>
<?php $component = App\View\Components\ProductCard::resolve(['image' => $item->image_url,'title' => $item->name,'description' => $item->description,'link' => ''.e(route('product-detail', ['id' => $item->id])).'','category' => $item->product_category->name,'price' => $item->price] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('product-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ProductCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalecfc721726b8b5798826c96d529d8b59)): ?>
<?php $attributes = $__attributesOriginalecfc721726b8b5798826c96d529d8b59; ?>
<?php unset($__attributesOriginalecfc721726b8b5798826c96d529d8b59); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalecfc721726b8b5798826c96d529d8b59)): ?>
<?php $component = $__componentOriginalecfc721726b8b5798826c96d529d8b59; ?>
<?php unset($__componentOriginalecfc721726b8b5798826c96d529d8b59); ?>
<?php endif; ?>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal49c970d3d2c20c30f4b317d550dfbdd2)): ?>
<?php $attributes = $__attributesOriginal49c970d3d2c20c30f4b317d550dfbdd2; ?>
<?php unset($__attributesOriginal49c970d3d2c20c30f4b317d550dfbdd2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal49c970d3d2c20c30f4b317d550dfbdd2)): ?>
<?php $component = $__componentOriginal49c970d3d2c20c30f4b317d550dfbdd2; ?>
<?php unset($__componentOriginal49c970d3d2c20c30f4b317d550dfbdd2); ?>
<?php endif; ?><?php /**PATH /Users/aji/Documents/eduwork-bootcamp/bootcamp-6/ecommerce-b6/resources/views/product-detail.blade.php ENDPATH**/ ?>