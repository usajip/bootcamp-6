<?php if (isset($component)) { $__componentOriginal49c970d3d2c20c30f4b317d550dfbdd2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal49c970d3d2c20c30f4b317d550dfbdd2 = $attributes; } ?>
<?php $component = App\View\Components\TemplateBootstrap::resolve(['title' => 'Cart Page with Component'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('template-bootstrap'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\TemplateBootstrap::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <div class="container">
        <div class="row">
            <div class="col-12 mb-4">
                <?php if(session('success')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('success')); ?>

                </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(session('error')); ?>

                </div>
                <?php endif; ?>
            </div>
            <div class="col-12 my-4">
                <h2>Cart Items</h2>
                <?php if(!empty($cart_items)): ?>
                    <div class="card p-4">
                        <h5 class="mb-4">
                            <i class="bi bi-bag me-2"></i> Shopping Cart (<?php echo e(count($cart_items)); ?> items)
                        </h5>
                        <?php $__currentLoopData = $cart_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="d-flex align-items-start <?php echo e($loop->last ? '' : 'border-bottom mb-4 pb-4'); ?>" style="gap: 1.5rem;">
                                <img src="<?php echo e($item['image_url'] ?? 'https://via.placeholder.com/100'); ?>" alt="<?php echo e($item['name']); ?>" class="rounded" style="width:100px; height:100px; object-fit:cover;">
                                <div class="flex-grow-1">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <div>
                                            <h5 class="mb-1"><?php echo e($item['name']); ?></h5>
                                            <div class="text-muted small mb-1"><?php echo e($item['description']); ?></div>
                                                <form method="POST" action="<?php echo e(route('cart.update', $item['id'])); ?>" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PUT'); ?>
                                                    <div class="input-group input-group-sm w-auto align-items-center">
                                                        <button class="btn btn-outline-secondary" onclick="event.preventDefault(); updateQuantity(<?php echo e($item['id']); ?>, 'decrement');" name="action" value="decrement" <?php echo e($item['quantity'] <= 1 ? 'disabled' : ''); ?>>-</button>
                                                        <input type="text" name="quantity" id="quantity-<?php echo e($item['id']); ?>" class="form-control text-center" value="<?php echo e($item['quantity']); ?>" style="width: 40px;" readonly>
                                                        <button class="btn btn-outline-secondary" onclick="event.preventDefault(); updateQuantity(<?php echo e($item['id']); ?>, 'increment');" name="action" value="increment">+</button>
                                                        <button class="btn btn-primary ms-2" type="submit" name="action" value="update">Update</button>
                                                    </div>
                                                </form>
                                        </div>
                                        <div class="text-end ms-3">
                                            <div class="fw-bold fs-5">Rp<?php echo e(number_format($item['price'], 0, ',', '.')); ?></div>
                                            <?php if($item['quantity'] > 1): ?>
                                                <div class="text-muted small">Rp<?php echo e(number_format($item['price'] * $item['quantity'], 0, ',', '.')); ?> total</div>
                                            <?php endif; ?>
                                            <a href="<?php echo e(route('cart.remove', $item['id'])); ?>" onclick="return confirm('Are you sure you want to remove this item from the cart?')" class="d-block mt-2 text-danger text-decoration-none">
                                                <i class="bi bi-trash me-1"></i> Remove
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <p>Your cart is empty.</p>
                    <a href="<?php echo e(url('/')); ?>" class="btn btn-primary mt-3">Continue Shopping</a>
                <?php endif; ?>
            </div>
            <div class="col-12 mb-5 d-flex justify-content-between align-items-center">
                <h5 class="mb-4">Cart Summary</h5>
                <div>
                    <h6>Items: <?php echo e(count($cart_items)); ?></h6>
                    <h4>Total: 
                        Rp<?php echo e(number_format(collect($cart_items)->reduce(function ($carry, $item) {
                            return $carry + ($item['price'] * $item['quantity']);
                        }, 0), 0, ',', '.')); ?>

                    </h4>
                </div>
            </div>
            <div class="col-12 mb-5">
                <a href="<?php echo e(url('/checkout')); ?>" class="btn btn-primary">Checkout</a>
            </div>
        </div>
     </div>
<script>
    function updateQuantity(productId, action) {
        const quantityInput = document.getElementById('quantity-' + productId);
        let currentQuantity = parseInt(quantityInput.value);
        if (action === 'increment') {
            currentQuantity += 1;
        } else if (action === 'decrement' && currentQuantity > 1) {
            currentQuantity -= 1;
        }
        quantityInput.value = currentQuantity;
    }
</script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal49c970d3d2c20c30f4b317d550dfbdd2)): ?>
<?php $attributes = $__attributesOriginal49c970d3d2c20c30f4b317d550dfbdd2; ?>
<?php unset($__attributesOriginal49c970d3d2c20c30f4b317d550dfbdd2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal49c970d3d2c20c30f4b317d550dfbdd2)): ?>
<?php $component = $__componentOriginal49c970d3d2c20c30f4b317d550dfbdd2; ?>
<?php unset($__componentOriginal49c970d3d2c20c30f4b317d550dfbdd2); ?>
<?php endif; ?><?php /**PATH /Users/aji/Documents/eduwork-bootcamp/bootcamp-6/ecommerce-b6/resources/views/cart.blade.php ENDPATH**/ ?>