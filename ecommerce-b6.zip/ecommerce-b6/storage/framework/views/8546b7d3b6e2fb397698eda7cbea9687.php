<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand" href="<?php echo e(route('home')); ?>">MyWebsite</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <?php if(Auth::check() && Auth::user()->role === 'admin'): ?>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('products.index')); ?>">Products</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('product-categories.index')); ?>">Product Categories</a>
        </li>
        <?php endif; ?>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('cart')); ?>">Keranjang</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('contact')); ?>">Contact</a>
        </li>
      </ul>
      <?php if(Auth::check()): ?>
        <ul class="navbar-nav mb-2 mb-lg-0">
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('profile.edit')); ?>">Profile</a>
            </li>
            <form class="d-flex" method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                <button class="btn btn-outline-success" type="submit" onclick="confirm('Are you sure you want to logout?')">Logout</button>
            </form>
        </ul>
        <?php else: ?>
        <ul class="navbar-nav mb-2 mb-lg-0">
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('register')); ?>">Register</a>
            </li>
        </ul>
      <?php endif; ?>
    </div>
  </div>
</nav><?php /**PATH /Users/aji/Documents/eduwork-bootcamp/bootcamp-6/ecommerce-b6/resources/views/template/navbar.blade.php ENDPATH**/ ?>