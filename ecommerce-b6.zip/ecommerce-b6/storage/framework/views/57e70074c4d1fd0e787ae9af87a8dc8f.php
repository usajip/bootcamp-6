<footer class="container">
    <p>&copy; 2025 My E-commerce Site</p>
</footer><?php /**PATH /Users/aji/Documents/eduwork-bootcamp/bootcamp-6/ecommerce-b6/resources/views/template/footer.blade.php ENDPATH**/ ?>