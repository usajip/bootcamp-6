<div class="alert alert-<?php echo e($type); ?> alert-dismissible fade show" role="alert">
  <?php echo e($slot); ?>

  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div><?php /**PATH /Users/aji/Documents/eduwork-bootcamp/bootcamp-6/ecommerce-b6/resources/views/components/alert.blade.php ENDPATH**/ ?>