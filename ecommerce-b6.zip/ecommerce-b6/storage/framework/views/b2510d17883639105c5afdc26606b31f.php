<?php if (isset($component)) { $__componentOriginal49c970d3d2c20c30f4b317d550dfbdd2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal49c970d3d2c20c30f4b317d550dfbdd2 = $attributes; } ?>
<?php $component = App\View\Components\TemplateBootstrap::resolve(['title' => 'Checkout Page with Component'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('template-bootstrap'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\TemplateBootstrap::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container my-5">
        <div class="row">
            <div class="col-12 mb-4">
                <?php if(session('success')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('success')); ?>

                </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger" role="alert">
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo $error; ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
            </div>
            <div class="col-12">
                <h2>Checkout</h2>
                <p>This is the checkout page. Implement your checkout process here.</p>
            </div>
            <?php if(auth()->guard()->guest()): ?>
            <div class="col-12 mt-4">
                <div class="alert alert-warning" role="alert">
                    Please <a href="<?php echo e(route('login')); ?>" class="alert-link">log in</a> to proceed with the checkout.
                </div>
            </div>
            <?php endif; ?>
            <?php if(!empty($cart_items)): ?>
                <div class="card p-4">
                    <h5 class="mb-4">
                        <i class="bi bi-bag me-2"></i> Shopping Cart (<?php echo e(count($cart_items)); ?> items)
                    </h5>
                    <?php $__currentLoopData = $cart_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex align-items-start <?php echo e($loop->last ? '' : 'border-bottom mb-4 pb-4'); ?>" style="gap: 1.5rem;">
                            <img src="<?php echo e($item['image_url'] ?? 'https://via.placeholder.com/100'); ?>" alt="<?php echo e($item['name']); ?>" class="rounded" style="width:100px; height:100px; object-fit:cover;">
                            <div class="flex-grow-1">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <h5 class="mb-1"><?php echo e($item['name']); ?></h5>
                                        <div class="text-muted small mb-1"><?php echo e($item['description']); ?></div>
                                        <div class="text-muted small">Quantity: <?php echo e($item['quantity']); ?></div>
                                    </div>
                                    <div class="text-end ms-3">
                                        <div class="fw-bold fs-5">Rp<?php echo e(number_format($item['price'], 0, ',', '.')); ?></div>
                                        <?php if($item['quantity'] > 1): ?>
                                            <div class="text-muted small">Rp<?php echo e(number_format($item['price'] * $item['quantity'], 0, ',', '.')); ?> total</div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php else: ?>
                <p>Your cart is empty.</p>
                <a href="<?php echo e(url('/')); ?>" class="btn btn-primary mt-3">Continue Shopping</a>
            <?php endif; ?>

            
            <div class="col-12 mt-4">
                <?php if(auth()->check() && !empty($cart_items)): ?>
                <form action="<?php echo e(route('checkout.process')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="address" class="form-label">Shipping Address</label>
                        <input type="text" class="form-control" id="address" name="address" required value="<?php echo e(auth()->user()->address ?? ''); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="phone" class="form-label">Phone Number</label>
                        <input type="text" class="form-control" id="phone" name="phone" required value="<?php echo e(auth()->user()->phone ?? ''); ?>">
                    </div>
                    <button type="submit" class="btn btn-success btn-lg">
                        <i class="bi bi-credit-card me-2"></i> Proceed to Payment
                    </button>
                </form>
                <?php else: ?>
                <button type="button" class="btn btn-success btn-lg" disabled>
                    <i class="bi bi-credit-card me-2"></i> Proceed to Payment
                </button>
                <?php endif; ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal49c970d3d2c20c30f4b317d550dfbdd2)): ?>
<?php $attributes = $__attributesOriginal49c970d3d2c20c30f4b317d550dfbdd2; ?>
<?php unset($__attributesOriginal49c970d3d2c20c30f4b317d550dfbdd2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal49c970d3d2c20c30f4b317d550dfbdd2)): ?>
<?php $component = $__componentOriginal49c970d3d2c20c30f4b317d550dfbdd2; ?>
<?php unset($__componentOriginal49c970d3d2c20c30f4b317d550dfbdd2); ?>
<?php endif; ?><?php /**PATH /Users/aji/Documents/eduwork-bootcamp/bootcamp-6/ecommerce-b6/resources/views/checkout.blade.php ENDPATH**/ ?>