<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ContohController extends Controller
{
    public function index()
    {
        // Logic untuk method index
        return "Ini adalah method index pada ContohController";
    }
}
